import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Chess } from "chess.js";
import useSound from "use-sound";
import { PromotionModal } from "./utils";
// const moveSound = new Howl({ src: ["../../assests/move-self.mp3"], volume: 1.0 });

function didCaptureOccur(lastFen, currentFen) {
  const getPieceCount = (fen) =>
    fen?.split(" ")?.[0]?.replace(/[\d/]/g, "")?.length;

  const lastCount = getPieceCount(lastFen);
  const currentCount = getPieceCount(currentFen);

  return currentCount < lastCount;
}

function findMoveFromFens(lastMoveFen, currentMoveFen) {
  const chessLast = new Chess(lastMoveFen);
  const chessCurrent = new Chess(currentMoveFen);

  // Generate all legal moves from the last position
  const moves = chessLast.moves({ verbose: true });
  for (let i = 0; i < moves.length; i++) {
    chessLast.move(moves[i]);
    if (chessLast.fen() === currentMoveFen) {
      // If the FENs match, we found our move
      return { from: moves[i].from, to: moves[i].to };
    }
    chessLast.undo(); // Undo the move to try the next one
  }

  return null; // If no move leads to the current FEN, return null
}

const ChessGame = ({
  children,
  position = "start",
  lastMoveFen,
  handleNewFen,
  skipValidation = false,
  ...rest
}) => {
  // const moveAudio = new Audio(moveSound);
  const [kingInCheckSquare, setKingInCheckSquare] = useState(null);

  const [moveSound] = useSound(
    "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/move-self.mp3"
  );

  const [captureSound] = useSound(
    "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/capture.mp3"
  );
  const [castlingSound] = useSound(
    "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/castle.mp3"
  );
  const [checkSound] = useSound(
    "https://images.chesscomfiles.com/chess-themes/sounds/_MP3_/default/move-check.mp3"
  );

  const chess = useMemo(
    () => {
      const chess = new Chess();
      const fen = position === "start" ? "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" : position;
      chess.load(fen, {
        skipValidation: skipValidation
      });
      return chess;
    },
    [position, skipValidation, rest?.resetChessboard]
  );
  const [fen, setFen] = useState(chess?.fen());
  const [lastMove, setLastMove] = useState(null);
  const [makeMoveFen, setMakeMoveFen] = useState(null);
  const [over, setOver] = useState("");
  const [isPromotionModalVisible, setIsPromotionModalVisible] = useState(false);
  const [promotionData, setPromotionData] = useState(null); // To store the source and target squares

  const [selectedSquare, setSelectedSquare] = useState(null);
  const [possibleMoves, setPossibleMoves] = useState([]);

  const onSquareSelected = useCallback(
    (square) => {
      setSelectedSquare(square);

      const moves = chess
        .moves({
          square: square,
          verbose: true,
        })
        .map((move) => move.to);

      setPossibleMoves(moves);
    },
    [chess]
  );

  useEffect(() => {
    
    const tempNewPosition = position === "start"
      ? "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
      : position
    
    if(tempNewPosition !== makeMoveFen){
      if (lastMoveFen) {
        // chess?.load?.(lastMoveFen); 
        // console.log('abcde loaded lastMoveFen', lastMoveFen);
        const timeoutId = setTimeout(() => {
          chess?.load(position); // After delay, set the board to positionFen
          setFen(tempNewPosition);
          const moveDetails = findMoveFromFens?.(lastMoveFen, position);
          setLastMove(moveDetails);
  
          // Check if a capture occurred and play the capture sound
          if (moveDetails && didCaptureOccur(lastMoveFen, position)) {
            captureSound();
          } else if (chess?.inCheck?.()) {
            checkSound(); // Play check sound
          } else {
            moveSound();
          }
          // setLastMove(findMoveFromFens(lastMoveFen, position));
        }, 10);

        setMakeMoveFen('');
  
        return () => clearTimeout(timeoutId);
          // setLastMove(findMoveFromFens(lastMoveFen, position));
      } else {
        
        // setLastMove({ from: "", to: "" });
        chess?.load(tempNewPosition, {
          skipValidation: skipValidation
        });
        setFen(tempNewPosition);
      }
      setMakeMoveFen('');
      
    }
    
  }, [position, lastMoveFen, rest?.resetChessboard]);

  function onDrop(sourceSquare, targetSquare, promotedPiece) {
    if (skipValidation && chess.turn() === "b") chess._turn = "w";

    try {
      const moveData = {
        from: sourceSquare,
        to: targetSquare,
        promotion: promotedPiece?.[1]?.toLowerCase(),
      };

      const allMoves = chess.moves({ verbose: true });

      const isValidMove = allMoves.some(
        (move) => move.from === sourceSquare && move.to === targetSquare
      );
      if (!isValidMove) return false;

      const shallStop = rest?.onPieceDropExtension?.(
        moveData.from,
        moveData.to,
        moveData.promotion
      );

      if (shallStop) return false;

      const move = makeAMove(moveData);
      if (!move) return false;

      if (move !== null) setLastMove({ from: sourceSquare, to: targetSquare });

      return move !== null;
    } catch (e) {
      console.error(e); // Log the error
      return false;
    }
  }

  // function onDrop(sourceSquare, targetSquare, promotedPiece) {
  //   try {
  //     const moveData = {
  //       from: sourceSquare,
  //       to: targetSquare,
  //       color: chess?.turn(),
  //       promotion: promotedPiece?.[1]?.toLowerCase() || "q",
  //     };

  //     // const moveData = {
  //     //   from: sourceSquare,
  //     //   to: targetSquare,
  //     //   promotion: promotedPiece?.[1]?.toLowerCase() || "q",
  //     // };

  //     // Check if the move is valid but don't make the move yet
  //     const isValidMove = chess
  //       ?.moves({ verbose: true })
  //       .some(
  //         (move) =>
  //           move.from === sourceSquare &&
  //           move.to === targetSquare &&
  //           (!promotedPiece ||
  //             move.promotion === promotedPiece[1].toLowerCase())
  //       );

  //     console.log(isValidMove, "isValidMove");
  //     if (!isValidMove) return false;

  //     // Check if the move should be stopped
  //     const shallStop = rest?.onPieceDropExtension?.(
  //       sourceSquare,
  //       targetSquare
  //     );
  //     console.log(shallStop, "shallStop");
  //     if (shallStop) {
  //       return false;
  //     }

  //     const move = makeAMove(moveData);
  //     if (!move) return false;

  //     // const shallStop = rest?.onPieceDropExtension?.(
  //     //   sourceSquare,
  //     //   targetSquare
  //     // );
  //     // console.log(shallStop, "shallStop");
  //     // if (shallStop) {
  //     //   return false;
  //     // }

  //     if (move !== null) {
  //       setLastMove({ from: sourceSquare, to: targetSquare });
  //     }
  //     return move !== null;
  //   } catch (e) {
  //     return false;
  //     //ignore
  //   }
  // }

  const makeAMove = useCallback(
    (move) => {
      try {
        const lastFen = chess.fen();
        const result = chess?.move(move);
        const newFen = chess.fen();
        if (result) {
          // Constructing move data
          const moveData = {
            from: result.from,
            to: result.to,
            piece: result.piece,
            san: result.san, // Standard Algebraic Notation of the move
            newFen: newFen, // New FEN string after the move
            lastFen: lastFen,
          };

          // Calling handleNewFen with the new FEN string and move data
          handleNewFen?.(moveData);
        }
        
        setFen(newFen);
        setMakeMoveFen(newFen);

        if (result && result.captured) {
          captureSound();
        } else if (chess?.inCheck?.()) {
          checkSound(); // Play check sound
        } else {
          moveSound();
        }
        if (chess?.isGameOver()) {
          if (chess?.isCheckmate()) {
            setOver(
              `Checkmate! ${chess?.turn() === "w" ? "black" : "white"} wins!`
            );
          } else if (chess?.isDraw()) {
            setOver("Draw");
          } else {
            setOver("Game over");
          }
        }

        return result;
      } catch (e) {
        return null;
      }
    },
    [chess, moveSound, captureSound, castlingSound, checkSound, handleNewFen]
  );

  useEffect(() => {
    if (chess?.inCheck?.()) {
      
      const kingPosition = findKingPosition(chess?.fen(), chess?.turn());
      setKingInCheckSquare(kingPosition);
    } else {
      setKingInCheckSquare(null);
    }
  }, [fen]);

  function findKingPosition(fen, turn) {
    const rows = fen?.split(" ")?.[0]?.split("/");
    const king = turn === "w" ? "K" : "k";

    for (let row = 0; row < rows?.length; row++) {
      let col = 0;
      for (const char of rows[row]) {
        if (char === king) {
          return String.fromCharCode(97 + col) + (8 - row);
        } else if (isNaN(char)) {
          col++;
        } else {
          col += parseInt(char, 10);
        }
      }
    }
    return null;
  }

  return (
    <>
      {/* <PromotionModal
        isOpen={isPromotionModalVisible}
        onSelect={handlePromotionSelection}
      /> */}
      {children({
        position: fen,
        onMove: onDrop,
        lastMove: lastMove,
        selectedSquare: selectedSquare,
        possibleMoves: possibleMoves,
        onSquareSelected: onSquareSelected,
        chess: chess,
        kingInCheckSquare: kingInCheckSquare,
        setSelectedSquare: setSelectedSquare,
        setPossibleMoves: setPossibleMoves,
        skipValidation: skipValidation,
        ...rest,
      })}
    </>
  );
};

export default ChessGame;
