import React, { useCallback, useEffect, useState } from "react";
import { Chessboard } from "react-chessboard";
import WhitePawn from "/node_modules/chessboard-package/assets/ChessPieces/White-Pawn.svg";
import WhiteRook from "/node_modules/chessboard-package/assets/ChessPieces/White-Rook.svg";
import WhiteQueen from "/node_modules/chessboard-package/assets/ChessPieces/White-Queen.svg";
import WhiteKnight from "/node_modules/chessboard-package/assets/ChessPieces/White-Knight.svg";
import WhiteKing from "/node_modules/chessboard-package/assets/ChessPieces/White-King.svg";
import WhiteBishop from "/node_modules/chessboard-package/assets/ChessPieces/White-Bishop.svg";
import BlackPawn from "/node_modules/chessboard-package/assets/ChessPieces/Black-Pawn.svg";
import BlackRook from "/node_modules/chessboard-package/assets/ChessPieces/Black-Rook.svg";
import BlackQueen from "/node_modules/chessboard-package/assets/ChessPieces/Black-Queen.svg";
import BlackKnight from "/node_modules/chessboard-package/assets/ChessPieces/Black-Knight.svg";
import BlackKing from "/node_modules/chessboard-package/assets/ChessPieces/Black-King.svg";
import BlackBishop from "/node_modules/chessboard-package/assets/ChessPieces/Black-Bishop.svg";
import BlackPawnCaptured from "/node_modules/chessboard-package/assets/ChessPieces/Black-Pawn-Captured.svg";
import BlackBishopCaptured from "/node_modules/chessboard-package/assets/ChessPieces/Black-Bishop-Captured.svg";
import BlackKnightCaptured from "/node_modules/chessboard-package/assets/ChessPieces/Black-Knight-Captured.svg";
import BlackRookCaptured from "/node_modules/chessboard-package/assets/ChessPieces/Black-Rook-Captured.svg";
import BlackKingCaptured from "/node_modules/chessboard-package/assets/ChessPieces/Black-King-Captured.svg";
import BlackQueenCaptured from "/node_modules/chessboard-package/assets/ChessPieces/Black-Queen-Captured.svg";
import WithTheIdea from "/node_modules/chessboard-package/assets/Annotation/with_the_idea.svg";
import WithCompensation from "/node_modules/chessboard-package/assets/Annotation/with_compensation.svg";
import TimeTrouble from "/node_modules/chessboard-package/assets/Annotation/time_trouble.svg";
import CounterPlay from "/node_modules/chessboard-package/assets/Annotation/counter_play.svg";
import Attack from "/node_modules/chessboard-package/assets/Annotation/attack.svg";
import Initiative from "/node_modules/chessboard-package/assets/Annotation/initiative.svg";
import Development from "/node_modules/chessboard-package/assets/Annotation/development.svg";
import BlackIsWinning from "/node_modules/chessboard-package/assets/Annotation/black_is_winning.svg";
import WhiteIsWinning from "/node_modules/chessboard-package/assets/Annotation/white_is_winning.svg";
import BlackIsBetter from "/node_modules/chessboard-package/assets/Annotation/black_is_better.svg";
import WhiteIsBetter from "/node_modules/chessboard-package/assets/Annotation/white_is_better.svg";
import BlackIsSlightlyBetter from "/node_modules/chessboard-package/assets/Annotation/black_is_slightly_better.svg";
import WhiteIsSlightlyBetter from "/node_modules/chessboard-package/assets/Annotation/white_is_slightly_better.svg";
import UnclearPosition from "/node_modules/chessboard-package/assets/Annotation/unclear_position.svg";
import EqualPosition from "/node_modules/chessboard-package/assets/Annotation/equal_position.svg";
import Zugzwand from "/node_modules/chessboard-package/assets/Annotation/zugzwand.svg";
import OnlyMove from "/node_modules/chessboard-package/assets/Annotation/only_move.svg";
import DubiousMove from "/node_modules/chessboard-package/assets/Annotation/dubious_move.svg";
import InterestingMove from "/node_modules/chessboard-package/assets/Annotation/interesting_move.svg";
import Blunder from "/node_modules/chessboard-package/assets/Annotation/blunder.svg";
import Mistake from "/node_modules/chessboard-package/assets/Annotation/mistake.svg";
import GoodMove from "/node_modules/chessboard-package/assets/Annotation/good_move.svg";

import WithTheIdea_white from "/node_modules/chessboard-package/assets/Annotation/white-color/with_the_idea_white.svg";
import WithCompensation_white from "/node_modules/chessboard-package/assets/Annotation/white-color/with_compensation_white.svg";
import TimeTrouble_white from "/node_modules/chessboard-package/assets/Annotation/white-color/time_trouble_white.svg";
import CounterPlay_white from "/node_modules/chessboard-package/assets/Annotation/white-color/counter_play_white.svg";
import Attack_white from "/node_modules/chessboard-package/assets/Annotation/white-color/attack_white.svg";
import Initiative_white from "/node_modules/chessboard-package/assets/Annotation/white-color/initiative_white.svg";
import Development_white from "/node_modules/chessboard-package/assets/Annotation/white-color/development_white.svg";
import BlackIsWinning_white from "/node_modules/chessboard-package/assets/Annotation/white-color/black_is_winning_white.svg";
import WhiteIsWinning_white from "/node_modules/chessboard-package/assets/Annotation/white-color/white_is_winning_white.svg";
import BlackIsBetter_white from "/node_modules/chessboard-package/assets/Annotation/white-color/black_is_better_white.svg";
import WhiteIsBetter_white from "/node_modules/chessboard-package/assets/Annotation/white-color/white_is_better_white.svg";
import BlackIsSlightlyBetter_white from "/node_modules/chessboard-package/assets/Annotation/white-color/black_is_slightly_better_white.svg";
import WhiteIsSlightlyBetter_white from "/node_modules/chessboard-package/assets/Annotation/white-color/white_is_slightly_better_white.svg";
import UnclearPosition_white from "/node_modules/chessboard-package/assets/Annotation/white-color/unclear_position_white.svg";
import EqualPosition_white from "/node_modules/chessboard-package/assets/Annotation/white-color/equal_position_white.svg";
import Zugzwand_white from "/node_modules/chessboard-package/assets/Annotation/white-color/zugzwand_white.svg";
import OnlyMove_white from "/node_modules/chessboard-package/assets/Annotation/white-color/only_move_white.svg";
import DubiousMove_white from "/node_modules/chessboard-package/assets/Annotation/white-color/dubious_move_white.svg";
import InterestingMove_white from "/node_modules/chessboard-package/assets/Annotation/white-color/interesting_move_white.svg";
import Blunder_white from "/node_modules/chessboard-package/assets/Annotation/white-color/blunder_white.svg";
import Mistake_white from "/node_modules/chessboard-package/assets/Annotation/white-color/mistake_white.svg";
import GoodMove_white from "/node_modules/chessboard-package/assets/Annotation/white-color/good_move_white.svg";

import CCColors from "../Utils/CCColors";

function isDarkSquare(square) {
  const file = square.charCodeAt(0); // Letter (a-h)
  const rank = parseInt(square[1], 10); // Number (1-8)
  return (file + rank) % 2 === 0;
}

// export
// Create an object mapping piece codes to image paths
export const pieceImages = {
  wP: WhitePawn,
  wR: WhiteRook,
  wQ: WhiteQueen,
  wN: WhiteKnight,
  wK: WhiteKing,
  wB: WhiteBishop,
  bP: BlackPawn,
  bR: BlackRook,
  bQ: BlackQueen,
  bN: BlackKnight,
  bK: BlackKing,
  bB: BlackBishop,
  bPC: BlackPawnCaptured,
  bBC: BlackBishopCaptured,
  bNC: BlackKnightCaptured,
  bRC: BlackRookCaptured,
  bQC: BlackQueenCaptured,
  bKC: BlackKingCaptured,
};
export const moveAnnotations = {
  "With the idea": { icon: WithTheIdea, white_icon: WithTheIdea_white },
  "With compensation": {
    icon: WithCompensation,
    white_icon: WithCompensation_white,
  },
  "Time trouble": { icon: TimeTrouble, white_icon: TimeTrouble_white },
  "Counter-play": { icon: CounterPlay, white_icon: CounterPlay_white },
  Attack: { icon: Attack, white_icon: Attack_white },
  Initiative: { icon: Initiative, white_icon: Initiative_white },
  Development: { icon: Development, white_icon: Development_white },
  "Black is winning": {
    icon: BlackIsWinning,
    white_icon: BlackIsWinning_white,
  },
  "White is winning": {
    icon: WhiteIsWinning,
    white_icon: WhiteIsWinning_white,
  },
  "Black is better": { icon: BlackIsBetter, white_icon: BlackIsBetter_white },
  "White is better": { icon: WhiteIsBetter, white_icon: WhiteIsBetter_white },
  "Black is slightly better": {
    icon: BlackIsSlightlyBetter,
    white_icon: BlackIsSlightlyBetter_white,
  },
  "White is slightly better": {
    icon: WhiteIsSlightlyBetter,
    white_icon: WhiteIsSlightlyBetter_white,
  },
  "Unclear position": {
    icon: UnclearPosition,
    white_icon: UnclearPosition_white,
  },
  "Equal position": { icon: EqualPosition, white_icon: EqualPosition_white },
  Zugzwang: { icon: Zugzwand, white_icon: Zugzwand_white },
  "Only move": { icon: OnlyMove, white_icon: OnlyMove_white },
  "Dubious move": { icon: DubiousMove, white_icon: DubiousMove_white },
  "Interesting move": {
    icon: InterestingMove,
    white_icon: InterestingMove_white,
  },
  Blunder: { icon: Blunder, white_icon: Blunder_white },
  Mistake: { icon: Mistake, white_icon: Mistake_white },
  "Good move": { icon: GoodMove, white_icon: GoodMove_white },
};

// Create a function to generate the piece theme using the mapping
const createPieceTheme = (pieceImages) => {
  return Object.keys(pieceImages).reduce((theme, piece) => {
    theme[piece] = ({ isDragging, squareWidth }) => (
      <img
        src={pieceImages[piece]}
        alt={piece}
        style={{
          height: squareWidth,
        }}
      />
    );
    return theme;
  }, {});
};

const ChessboardComponentInner = React.forwardRef((props, ref) => {
  const {
    disabled,
    position,
    onMove,
    lastMove,
    chess,
    kingInCheckSquare,
    boardOrientation,
    selectedSquare,
    possibleMoves,
    onSquareSelected,
    setSelectedSquare,
    setPossibleMoves,
    restrictedPiece,
    restrictPiece,
    colorTheme,
    annotation = null,
    skipValidation = false,
    customPositions = {},
    ...rest
  } = props;

  const [arrows, setArrows] = useState([]);
  const [dragStartSquare, setDragStartSquare] = useState([]);
  const [promotionSourceSquare, setPromotionSourceSquare] = useState(null);
  const [startPieceDrag, setStartPieceDrag] = useState(false);
  const [promotionTargetSquare, setPromotionTargetSquare] = useState(null);
  const [showPromotionDialog, setShowPromotionDialog] = useState(false);
  const [promotionPiece, setPromotionPiece] = useState(null);
  const [lastMoveSquare, setLastMoveSquare] = useState(null);

  useEffect(() => {
    // Set the target square of the last move
    if (lastMove?.to) {
      setLastMoveSquare(lastMove.to);
    }
  }, [lastMove]);

  useEffect(() => {
    const chessboardEl = document.getElementById("BoardWithCustomArrows");
    if (chessboardEl) {
      chessboardEl.addEventListener("mousedown", handleMouseDown);
      chessboardEl.addEventListener("mousemove", handleMouseMove);
      chessboardEl.addEventListener("mouseup", handleMouseUp);

      // Prevent context menu on right click
      chessboardEl.oncontextmenu = (e) => e.preventDefault();
    }

    return () => {
      if (chessboardEl) {
        chessboardEl.removeEventListener("mousedown", handleMouseDown);
        chessboardEl.removeEventListener("mousemove", handleMouseMove);
        chessboardEl.removeEventListener("mouseup", handleMouseUp);

        chessboardEl.oncontextmenu = null;
      }
    };
  }, [handleMouseDown, handleMouseMove, handleMouseUp]);

  const getSquareName = (file, rank, boardOrientation) => {
    if (boardOrientation === "white") {
      return file + rank; // Default orientation (white)
    } else {
      const reversedFile = String.fromCharCode(
        "h".charCodeAt(0) - (file.charCodeAt(0) - "a".charCodeAt(0))
      );
      const reversedRank = 9 - rank; // Reverse rank
      return reversedFile + reversedRank;
    }
  };

  const renderAnnotation = () => {
    if (lastMoveSquare) {
      const [file, rank] = lastMoveSquare.split("");
      const correctSquare = getSquareName(
        file,
        parseInt(rank, 10),
        boardOrientation
      );
      const [correctFile, correctRank] = correctSquare.split("");

      const left = (correctFile.charCodeAt(0) - "a".charCodeAt(0)) * 12.5 + "%";
      const top = (8 - parseInt(correctRank)) * 12.5 + "%";

      if (!annotation) return null;

      return (
        <div
          key={lastMoveSquare}
          style={{
            position: "absolute",
            top,
            left,
            width: "12.5%",
            height: "12.5%",
            pointerEvents: "none",
          }}
        >
          <div style={styles.annotationContainer}>
            <img
              src={moveAnnotations?.[annotation]?.white_icon}
              alt="annotation"
              style={styles.icon}
            />
          </div>
        </div>
      );
    }
    return null;
  };

  const handleMouseDown = useCallback((event) => {
    if (event.button === 2) {
      const square = getSquareFromMouseEvent(event);
      if (square) {
        setDragStartSquare(square);
      }
      event.preventDefault();
    }
  }, []);

  const handleMouseMove = useCallback(
    (event) => {
      if (!dragStartSquare) return;

      const currentSquare = getSquareFromMouseEvent(event);
      // Update some temporary state or UI to show the in-progress arrow if needed
    },
    [dragStartSquare]
  );

  const handleMouseUp = useCallback(
    (event) => {
      if (dragStartSquare) {
        const endSquare = getSquareFromMouseEvent(event);
        if (endSquare) {
          setArrows((prevArrows) => [
            ...prevArrows,
            { from: dragStartSquare, to: endSquare },
          ]);
        }
      }
      setDragStartSquare(null);
    },
    [dragStartSquare]
  );
  const onPieceDrop = useCallback(
    (sourceSquare, targetSquare, promotion) => {
      const piece = chess.get(sourceSquare); // Get the piece on the source square
      // Check if restriction is enabled, and only allow moves from the restricted piece
      if (
        restrictedPiece &&
        (piece?.type !== restrictedPiece.type ||
          sourceSquare !== restrictedPiece.square)
      ) {
        return false; // Prevent the move if it's not the restricted piece
      }
      // if (restrictedPiece && piece?.color !== restrictedPiece.color) {
      //   return false; // Prevent the move if it's not the restricted piece
      // }

      const isMoveSuccessful = onMove(sourceSquare, targetSquare, promotion);

      // If the move is valid, proceed
      if (isMoveSuccessful) {
        setSelectedSquare(null);
        setPossibleMoves([]);
      }
      return isMoveSuccessful;
    },
    [chess, restrictedPiece, onMove, setSelectedSquare, setPossibleMoves]
  );

  const onSquareClick = useCallback(
    (square) => {
      if (disabled) return;
      if (skipValidation && chess.turn() === "b") chess._turn = "w";

      const piece = chess.get(square);
      setStartPieceDrag(false);

      // Handle restricted piece (if necessary)
      if (
        restrictedPiece &&
        !possibleMoves.includes(square) &&
        (piece?.type !== restrictedPiece.type ||
          square !== restrictedPiece.square)
      ) {
        return false; // Do nothing if the clicked piece is not the restricted one
      }
      if (restrictPiece) {
        restrictPiece(piece, square);
      }

      // If the selected square is valid and it's a promotion move
      if (selectedSquare && possibleMoves.includes(square)) {
        const pieceDetails = chess.get(selectedSquare);

        // Detect if the move involves a pawn promotion
        if (
          (pieceDetails?.type === "p" &&
            pieceDetails?.color === "w" &&
            square[1] === "8") ||
          (pieceDetails?.type === "p" &&
            pieceDetails?.color === "b" &&
            square[1] === "1")
        ) {
          setPromotionSourceSquare(selectedSquare);
          setPromotionTargetSquare(square);
          setShowPromotionDialog(true); // Show promotion dialog
          return;
        }

        // Otherwise, just make a normal move
        onMove(selectedSquare, square);
        setSelectedSquare(null);
        setPossibleMoves([]);
        return;
      }

      // Select the piece and show possible moves
      setSelectedSquare(square);
      const moves = chess
        .moves({
          square: square,
          verbose: true,
        })
        .map((move) => move.to);
      setPossibleMoves(moves);
    },
    [chess, onMove, possibleMoves, selectedSquare, disabled, restrictedPiece]
  );

  const onPromotionPieceSelect = useCallback(
    (promotedPiece) => {
      // Handle promotion for both drag-and-drop and click-based moves
      if (promotionSourceSquare && promotionTargetSquare) {
        onMove(promotionSourceSquare, promotionTargetSquare, promotedPiece);
        setPromotionSourceSquare(null);
        setPromotionTargetSquare(null);
        setShowPromotionDialog(false); // Close the promotion modal
      }
    },
    [promotionSourceSquare, promotionTargetSquare, onMove]
  );

  //   ,
  //   [selectedSquare, possibleMoves, onMove, onSquareSelected, disabled]
  // );

  useEffect(() => {
    if (selectedSquare) {
      squareStyles[selectedSquare] = {
        backgroundColor: "rgba(20, 85, 30, 0.5)",
      };
    }
    if (possibleMoves) {
      possibleMoves?.forEach((move) => {
        squareStyles[move] = { backgroundColor: "rgba(20, 85, 30, 0.3)" };
      });
    }
  }, [selectedSquare, possibleMoves]);

  let color = colorTheme;
  let lightColor = CCColors.ChessBoard.Light;
  let darkColor = CCColors.Progress.Bar;
  let startColor = CCColors.ChessBoard.StartColor;
  let endColor = CCColors.ChessBoard.EndColor;
  if (color) {
    if (color === "green-white") {
      lightColor = CCColors.ChessBoard.GreenLightColor;
      darkColor = CCColors.ChessBoard.GreenDarkColor;
      startColor = CCColors.ChessBoard.GreenStartColor;
      endColor = CCColors.ChessBoard.GreenEndColor;
    } else if (color === "blue-white") {
      lightColor = CCColors.ChessBoard.BlueLightColor;
      darkColor = CCColors.ChessBoard.BlueDarkColor;
      startColor = CCColors.ChessBoard.BlueStartColor;
      endColor = CCColors.ChessBoard.BlueEndColor;
    }
  }

  const squareStyles = {};

  ["a", "b", "c", "d", "e", "f", "g", "h"].forEach((r) =>
    ["1", "2", "3", "4", "5", "6", "7", "8"].forEach((c) => {
      const square = r + c;
      const isDark = isDarkSquare(square);
      squareStyles[square] = {
        border: "2px solid transparent",
        boxSizing: "border-box",
        backgroundColor: isDark ? darkColor : lightColor,
        color: isDark ? lightColor : darkColor, // Dynamic notation color based on square color
      };
    })
  );

  if (lastMove?.from && isValidSquare(lastMove.from)) {
    // squareStyles[lastMove.from].backgroundColor = "rgb(120, 113, 64)";
    squareStyles[lastMove.from].backgroundColor = startColor;
  }

  if (lastMove?.to && isValidSquare(lastMove.to)) {
    // squareStyles[lastMove.to].backgroundColor = "rgb(196, 181, 57)";
    squareStyles[lastMove.to].backgroundColor = endColor;
    squareStyles[lastMove.to].border = "2px solid rgb(120, 113, 64)";
  }

  if (kingInCheckSquare && isValidSquare(kingInCheckSquare)) {
    squareStyles[kingInCheckSquare].background =
      "radial-gradient(transparent 60%, #EB5757)";
  }else{
    
  }

  if (restrictedPiece) {
    squareStyles[restrictedPiece?.square] = {
      backgroundColor: "rgba(20, 85, 35, 0.3)",
    };
  }
  // Handle drag start
  const onPieceDragBegin = useCallback((piece, sourceSquare) => {
    // Set the source square when dragging starts
    setStartPieceDrag(true);
    if (skipValidation && chess.turn() === "b") chess._turn = "w";
    const Piece = {
      type: piece[1].toLowerCase(),
      square: sourceSquare,
      color: piece[0],
    };
    if (restrictPiece) {
      restrictPiece(Piece, sourceSquare);
    }

    return true; // Allow normal moves
  }, []);

  // Handle drag end
  const onPieceDragEnd = useCallback(
    (piece, targetSquare) => {
      // setStartPieceDrag(false);

      return true; // Allow normal moves
    },
    [chess, promotionSourceSquare]
  );

  function fenToPosition(fen) {
    const ranks = fen.split(" ")[0].split("/");
    const position = {};

    for (let rankIndex = 0; rankIndex < 8; rankIndex++) {
      let fileIndex = 0;
      for (let i = 0; i < ranks[rankIndex].length; i++) {
        const char = ranks[rankIndex][i];

        if (isNaN(char)) {
          // Piece character
          const square = String.fromCharCode(97 + fileIndex) + (8 - rankIndex);
          position[square] =
            char === char.toUpperCase() ? "w" + char : "b" + char.toUpperCase();
          fileIndex++;
        } else {
          // Empty spaces
          fileIndex += parseInt(char, 10);
        }
      }
    }
    return position;
  }

  function getUpdatedFenObject(position) {
    var obj = fenToPosition(position);
    var updatedPositions = { ...obj, ...customPositions };
    return updatedPositions;
  }

  const pieceTheme = createPieceTheme(pieceImages);
  return (
    <div style={{ position: "relative" }}>
      <Chessboard
        ref={ref}
        position={getUpdatedFenObject(position)}
        arePiecesDraggable={disabled ? false : true}
        customBoardStyle={disabled ? { pointerEvents: "none" } : {}}
        showBoardNotation={true}
        promotionDialogVariant="modal"
        customPieces={pieceTheme}
        customDarkSquareStyle={{ backgroundColor: darkColor }}
        customLightSquareStyle={{ backgroundColor: lightColor }}
        onPieceDrop={onPieceDrop}
        onSquareClick={onSquareClick}
        customNotationStyle={{
          color: "auto",
          fontSize: 16,
          // fontWeight: "bold",
        }}
        customSquareStyles={squareStyles}
        boardOrientation={boardOrientation}
        id="BoardWithCustomArrows"
        // customArrows={customArrows}
        customArrows={arrows}
        customArrowColor={"rgb(245, 192, 0)"}
        showPromotionDialog={showPromotionDialog} // Show promotion dialog when needed
        {...(!startPieceDrag && {
          onPromotionPieceSelect: onPromotionPieceSelect,
        })}
        onPieceDragBegin={onPieceDragBegin}
        onPieceDragEnd={onPieceDragEnd}
        // onArrowsChange={(squares) => {
        //   console.log(squares, "squares");
        // }}
        {...rest}
        // onPieceDragBegin={onPieceDragStart}
        // onPieceDragEnd={onPieceDragEnd}
        // showPromotionDialog={showPromotionDialog}
        // onPromotionPieceSelect={onPromotionPieceSelect}
        // {...(lastMove?.from &&
        //   lastMove?.to && {
        //     customArrows: [{ from: lastMove.from, to: lastMove.to }],
        //   })}
      />
      {renderAnnotation()}
    </div>
  );
});

function isValidSquare(square) {
  return /^[a-h][1-8]$/.test(square);
}
const styles = {
  annotationContainer: {
    position: "absolute",
    top: "-15%", // Positioning within the square
    right: "-20%",
    width: "40%",
    height: "40%",
    minWidth: "25px",
    minHeight: "25px",
    backgroundColor: CCColors.ChessBoard.OrangeColor, // Circle color
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  icon: {
    width: "14px",
    height: "14px",
  },
};
export default ChessboardComponentInner;
