// React Native component (ChessboardComponentInner.native.js)
import React from "react";
import { Chessboard } from "react-native-chessboard";
import ChessGame from "./ChessGame";

const ChessboardComponentInner = (props) => {
  return (
    <ChessGame>
      {({ position, onSquareClick, onMove, }) => (
        <Chessboard
          {...props}
          position={position}
          onSquareClick={onSquareClick}
          onMove={onMove}
        />
      )}
    </ChessGame>
  );
};

export default ChessboardComponentInner;
