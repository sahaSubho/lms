import React from "react";

export function PromotionModal({ isOpen, onSelect }) {
  if (!isOpen) return null;

  return (
    <div className="modal">
      <h3>Choose piece for promotion</h3>
      <button onClick={() => onSelect("q")}>Queen</button>
      <button onClick={() => onSelect("r")}>Rook</button>
      <button onClick={() => onSelect("b")}>Bishop</button>
      <button onClick={() => onSelect("n")}>Knight</button>
    </div>
  );
}
