import React, { useState, useEffect, useCallback } from "react";
import ChessboardComponentInner, { pieceImages } from "./components/Chessboard";
import ChessGame from "./components/ChessGame";

const ChessboardComponent = React.forwardRef((props, ref) => {
  console.log(props, "ChessboardComponent");

  // const [arrows, setArrows] = useState([]); // To store the arrows

  // const handleSquareRightClick = useCallback(
  //   (square) => {
  //     debugger;
  //     // Assuming you want to toggle arrows off if clicked again
  //     const existingArrowIndex = arrows.findIndex(
  //       (arrow) => arrow.from === square
  //     );
  //     if (existingArrowIndex !== -1) {
  //       // Remove the arrow if it already exists
  //       setArrows((currentArrows) =>
  //         currentArrows.filter((_, index) => index !== existingArrowIndex)
  //       );
  //     } else {
  //       // Add a new arrow (this example just points the arrow back to itself, you'll need logic to choose the 'to' square)
  //       const newArrow = { from: square, to: square }; // Update 'to' based on your logic
  //       setArrows((currentArrows) => [...currentArrows, newArrow]);
  //     }
  //   },
  //   [arrows, setArrows]
  // );

  // const handleArrowsChange = useCallback(
  //   (newArrows) => {
  //     // Update your arrows state based on the new arrows, if necessary
  //     // This can be useful if the chessboard package provides built-in functionality for modifying arrows
  //     setArrows(newArrows);
  //   },
  //   [setArrows]
  // );
  return (
    <ChessGame position={props.position} {...props}>
      {({ position, onMove, lastMove, ...rest }) => (
        <ChessboardComponentInner
          ref={ref}
          {...rest}
          disabled={props.disabled}
          position={position}
          onMove={onMove}
          lastMove={lastMove}
          restrictedPiece={props.restrictedPiece}
          restrictPiece={props.restrictPiece}
          annotation={props?.annotation}
          // onSquareRightClick={handleSquareRightClick}
          // onArrowsChange={handleArrowsChange}
          // arrows={arrows}
        />
      )}
    </ChessGame>
  );
});

export const PieceImages = pieceImages;
export default ChessboardComponent;
